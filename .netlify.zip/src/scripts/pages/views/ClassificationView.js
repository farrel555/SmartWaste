// src/scripts/pages/views/ClassificationView.js

import BaseView from './BaseView';

class ClassificationView extends BaseView {
    constructor(containerId) {
        super(containerId);
    }

    /**
     * Metode utama untuk menampilkan hasil klasifikasi yang berhasil.
     * @param {string} imageSrc - Sumber gambar yang di-scan (data URL).
     * @param {string} wasteType - Jenis sampah hasil klasifikasi (misal, 'organik').
     */
    render(imageSrc, wasteType) {
        // Teks rekomendasi sederhana berdasarkan jenis sampah
        let recommendationText = 'Informasi lebih lanjut tidak tersedia.';
        switch (wasteType.toLowerCase()) {
            case 'organik':
                recommendationText = 'Sampah ini dapat diolah menjadi kompos atau pakan ternak.';
                break;
            case 'anorganik':
                recommendationText = 'Dapat didaur ulang. Pisahkan dan setorkan ke bank sampah.';
                break;
            case 'b3':
                recommendationText = 'Berbahaya! Buang ke fasilitas penampungan limbah B3 khusus.';
                break;
            case 'residu':
                recommendationText = 'Buang ke tempat sampah sebagai pilihan terakhir.';
                break;
        }

        this.container.innerHTML = `
            <div class="card classification-card">
                <div class="page-specific-header">
                    <div class="page-header-logo"><i class="fas fa-check-circle"></i> Hasil Klasifikasi</div>
                </div>
                <h2>Hasil Scan Ditemukan</h2>
                <div class="classification-result">
                    <img src="${imageSrc}" alt="Gambar yang di-scan">
                    <p>Jenis Sampah: <strong>${wasteType.charAt(0).toUpperCase() + wasteType.slice(1)}</strong></p>
                    <p class="recommendation-text">${recommendationText}</p>
                </div>
                <button class="btn" id="scan-again-btn">Scan Lagi</button>
            </div>
        `;
        this.bindEvents();
    }

    /**
     * (BARU) Metode untuk menampilkan status loading.
     */
    showLoading() {
        this.container.innerHTML = `
            <div class="card classification-card">
                <div class="page-specific-header">
                    <div class="page-header-logo"><i class="fas fa-spinner fa-spin"></i> Menganalisis</div>
                </div>
                <h2>Menganalisis Gambar...</h2>
                <p>Harap tunggu, sistem kami sedang mengidentifikasi jenis sampah.</p>
            </div>
        `;
    }

    /**
     * (BARU) Metode untuk menampilkan pesan error.
     * @param {string} message - Pesan error yang akan ditampilkan.
     */
    showError(message) {
        this.container.innerHTML = `
            <div class="card classification-card error-card">
                 <div class="page-specific-header">
                    <div class="page-header-logo"><i class="fas fa-exclamation-triangle"></i> Terjadi Error</div>
                </div>
                <h2>Oops! Terjadi Kesalahan</h2>
                <p>${message}</p>
                <button class="btn" id="scan-again-btn">Coba Scan Lagi</button>
            </div>
        `;
        this.bindEvents(); // Bind event untuk tombol "Scan Lagi" di halaman error
    }

    bindEvents() {
        // Event listener untuk tombol 'Scan Lagi'
        const scanAgainButton = this.container.querySelector('#scan-again-btn');
        if (scanAgainButton && this.presenter && this.presenter.appRouter) {
             this.bind('click', '#scan-again-btn', () => {
                this.presenter.appRouter.navigateTo('scan');
            });
        }
    }
}

export default ClassificationView;